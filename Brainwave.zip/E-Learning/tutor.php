<?php
session_start();
    include('function.php');
    include('connect.php');

    if(isset($_POST['save_datetime']))
    {
        $name = $_POST['name'];
        $datetime = $_POST['datetime'];
        
        
        $checkQuery = "SELECT * FROM booking WHERE name='$name' AND datetime='$datetime'";
        $checkResult = mysqli_query($con, $checkQuery);

        if (mysqli_num_rows($checkResult) > 0) {
            
            $_SESSION['status'] = "Error: This time has already been booked, Please try booking diffrence time";
        } else {
            
            $query = "INSERT INTO booking (name,datetime) VALUES ('$name','$datetime')";
            
            $query = mysqli_query($con, $query);

            if($query)
            {
                $_SESSION['status'] = "You have booked the tutor.";
                header("Location: payment.html");
                exit(); 
            }
            else{
                $_SESSION['status'] = "Error: Could not complete the booking.";
            }
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/tutor.css">
    <link rel="stylesheet" href="styles/navbar.css">    
    <title>Tutor</title>
</head>
<body>
    <nav class="navbar">
        <div class="nav-brand">Brainwave</div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="english.html">English</a></li>
            <li><a href="mathciamtic.html">Mathciamtic</a></li>
            <li><a href="user.php">Account</a></li>
            <li><a href="support.html">Support</a></li>
        </ul>
    </nav> 

    <h1>Tutoring</h1>
    
    <div class="container">
        <p class="detail">NOTE: This tutor will not be available free of charge to all users. Individuals must schedule a session with the tutor and complete the payment process before they can access the learning services provided.</p>
        <div class="content">
        <h2>Selecting your tutor</h2>
        <div class="scrollable">
            <table>
                <tr>
                    <td>Tutor Name</td>
                    <td>Subject</td>
                    <td>Teaching Exprience</td>
                </tr>
                <tr>
                    <th>James Smith</th>
                    <th>English</th>
                    <th>2 years</th>
                    
                </tr>
                <tr>
                    <th>Mary Murphy</th>
                    <th>English</th>
                    <th>1 year</th>
                </tr>
                <tr>
                    <th>Elizabeth Walsh</th>
                    <th>English</th>
                    <th>5 years</th>
                </tr>
                <tr>
                    <th>Susan Brown</th>
                    <th>English</th>
                    <th>4 years</th>
                </tr> 
                <tr>
                    <th>Charles Williams</th>
                    <th>English</th>
                    <th>2 yeras</th>
                </tr>
                <tr>
                    <th>Christopher	Wilson</th>
                    <th>English</th>
                    <th>1 year</th>
                </tr> 
                <tr>
                    <th>Sandra Miller</th>
                    <th>Mathematic</th>
                    <th>1 year</th>
                </tr> 
                <tr>
                    <th>Mark Rodriguez</th>
                    <th>Mathematic</th>
                    <th>4 years</th>
                </tr> 
                <tr>
                    <th>Emily Li</th>
                    <th>Mathematic</th>
                    <th>2 years</th>
                </tr> 
                <tr>
                    <th>Paul Jones</th>
                    <th>Mathematic</th>
                    <th>3 years</th>
                </tr> 
                <tr>
                    <th>Carol Wang</th>
                    <th>Mathematic</th>
                    <th>1 years</th>
                </tr> 
                <tr>
                    <th>Amanda 	Anderson</th>
                    <th>Mathematic</th>
                    <th>6 years</th>
                </tr>
            </table>

            </div>
            
            <form method="POST">
                <div class="form-group">
                    <label for="tutor">Tutor Name</label>
                    <select name="name" class="form-controrl">
                        <option> n/a</option>
                        <option>James Smith</option>
                        <option>Mary Murphy</option>
                        <option>Elizabeth Walsh</option>
                        <option>Susan Brown</option>
                        <option>Charles Williams</option>
                        <option>Christopher	Wilson</option>
                        <option>Sandra Miller</option>
                        <option>Mark Rodriguez</option>
                        <option>Emily Li</option>
                        <option>Paul Jones</option>
                        <option>Carol Wang</option>
                        <option>Amanda 	Anderson</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="">Date and Time</label>
                    <input type="datetime-local" name="datetime" class="form-control" required>
                </div>
                <div class="form-group">
                    <input type="submit" name="save_datetime" class="book-btn" value="Booking">

                </div>


            </form>

            <?php
            // Display status message
            if (isset($_SESSION['status'])) {
                echo "<div class='status-message'>" . $_SESSION['status'] . "</div>";
                unset($_SESSION['status']);
            }
            ?>
        </div>

        

    </div>

    

    <div class="back-button">
        <a href="index.php" class="back-btn">← Back to Home</a>
    </div>


</body> 
</html>