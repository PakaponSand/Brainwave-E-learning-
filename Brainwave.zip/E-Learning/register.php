<?php
session_start();

    include('function.php');
    include('connect.php');

    if($_SERVER['REQUEST_METHOD'] == "POST")
    {   
        //something was posted
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];

        if(!empty($username) && !empty($password) && !empty($email))
        {
            
            //save to database
            $user_id = random_num(20);
            $query = "insert into registration (user_id,username,password,email) values ('$user_id','$username','$password','$email')";
            
            mysqli_query($con, $query);

            header("Location: login.php");
            die;
        }else{
            echo "Please enter some valid information!";
        }   
    }
?>

<!doctype html>
<html>

<head>
<meta charset="UTF-8">
<title>Signup</title>
<link rel="stylesheet" href="styles/signup.css">
<link rel="stylesheet" href="styles/navbar.css">
</head>

<body>
    <nav class="navbar">
        <div class="nav-brand">Brainwave</div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="english.html">English</a></li>
            <li><a href="mathciamtic.html">Mathciamtic</a></li>
            <li><a href="user.php">Account</a></li>
            <li><a href="support.html">Support</a></li>
        </ul>
    </nav> 
    
    <div class="wrapper">
        <form method="post">
            <h1>Sign Up </h1>

            <div class="input-box">
                <input type="text" placeholder="Username" required name="username">
            </div>

            <div class="input-box">
                <input type="password" placeholder="Password" required name="password">
            </div>

            <div class="input-box">
                <input type="email" placeholder="Email" required name="email">
            </div>

            <input type="submit" class="signup-btn" value="Signup">

            <div class="login-link">
                 <p>Are you alredey have an accrount! <a href="login.php">Login</a></p>
                
            </div>
        </form>
    </div>

</body>

</html>