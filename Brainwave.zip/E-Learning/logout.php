<?php
    session_start();
    
    if(isset($_SESSION['user_id']))
    {
        unset($_SESSION['user_id']);
    }
    
    // Destroy the session
    session_destroy();
    
    // Redirect to login page
    header("Location: index.php");
    exit();
?>