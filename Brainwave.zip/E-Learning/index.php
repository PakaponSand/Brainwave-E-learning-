<?php
session_start();
include("connect.php");
include("function.php");

// Check if user is logged in
if(!isset($_SESSION['user_id']))
{

}

// Get user data
$user_data = null;
if(isset($_SESSION['user_id']))
{
    $query = "SELECT * FROM registration WHERE user_id = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "s", $_SESSION['user_id']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if($result && mysqli_num_rows($result) > 0)
    {
        $user_data = mysqli_fetch_assoc($result);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brainwave</title>
    <link rel="stylesheet" href="styles/index.css">
    <link rel="stylesheet" href="styles/navbar.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-brand">Brainwave</div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="english.html">English</a></li>
            <li><a href="mathciamtic.html">Mathciamtic</a></li>
            <li><a href="user.php">Account</a></li>
            <li><a href="support.html">Support</a></li>
        </ul>
    </nav> 

    <div class="container">
        <h1>Welcome to Brainwave</h1>
        <?php if($user_data): ?>
            <h2>Hello, <?php echo htmlspecialchars($user_data['username']); ?></h2>
        <?php else: ?>
            <p>Please login to record your data</p>
        <?php endif; ?>
        
        <div class="subject">
            <div class="content" >
                <img src="./english/english-def.jpg" alt="English img">
                <p>English means belonging or relating to England, or to its people, language, or culture. It is also often used to mean belonging or relating to Great Britain.</p>
                <a href="english.html">learn more about English</a>
            </div>

            <div class="content" >
                <img src="./mathematics/math-def.jpg" alt="Mathematics img">
                <p>Mathematics is the science and study of quality, structure, space, and change. Mathematicians seek out patterns, formulate new conjectures, and establish truth by rigorous deduction from appropriately chosen axioms and definitions.</p>
                <a href="mathciamtic.html">learn more about Mathematics</a>
            </div>
        </div>
        <div class="subject">
            <div class="content">
                <img src="./english/tutoring.jpg" alt="Tutor img">
                <p>NOTE: This tutor will not be available free of charge to all users. Individuals must schedule a session with the tutor and complete the payment process before they can access the learning services provided.</p>
                <a href="tutor.php">Select your tutor</a>

            </div>

            <div class="content">
                <img src="./english/userimg.jpg" alt="User img">
                <p>User Account</p>
                <a href="user.php">Edit user detail</a>

            </div>

        </div>
       
        <?php if($user_data): ?>
            <div class="logout-link">
                <a href="logout.php">Logout</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
