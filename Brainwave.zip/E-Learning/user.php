<?php
session_start();

    include('function.php');
    include('connect.php');

    // Check if user_id is set in the session
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['update'])) {   
        // Get the user ID from the session
        $userId = $_SESSION['user_id'];
        
        // Get the posted data
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];

        if (!empty($username) && !empty($email)) {
            // Prepare the update query
            $query = "UPDATE registration SET username = ?, email = ?" . (!empty($password) ? ", password = ?" : "") . " WHERE user_id = ?";
            
            // Prepare the statement
            $stmt = mysqli_prepare($con, $query);
            
            if (!empty($password)) {
                mysqli_stmt_bind_param($stmt, "sssi", $username, $email, $password, $userId);
            } else {
                mysqli_stmt_bind_param($stmt, "ssi", $username, $email, $userId);
            }

            // Execute the statement
            if (mysqli_stmt_execute($stmt)) {
                echo "<script>alert('User details updated successfully!');</script>";
            } else {
                echo "<script>alert('Failed to update user details.');</script>";
            }
        } else {
            echo "Please enter some valid information!";
        }   
    }

    // Handle account deletion
    if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['delete_account'])) {
        $userId = $_SESSION['user_id'];

        // Prepare the delete query
        $deleteQuery = "DELETE FROM registration WHERE user_id = ?";
        $deleteStmt = mysqli_prepare($con, $deleteQuery);
        mysqli_stmt_bind_param($deleteStmt, "s", $userId);

        // Execute the delete statement
        if (mysqli_stmt_execute($deleteStmt)) {
            // Log out the user and redirect to the home page
            session_destroy();
            header("Location: index.php");
            exit();
        } else {
            echo "<script>alert('Failed to delete account.');</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/user.css">
    <link rel="stylesheet" href="styles/navbar.css">    
    <title>User</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <nav class="navbar">
        <div class="nav-brand">Brainwave</div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="english.html">English</a></li>
            <li><a href="mathciamtic.html">Mathciamtic</a></li>
            <li><a href="user.php">Account</a></li>
            <li><a href="support.html">Support</a></li>
        </ul>
    </nav> 

    <div class="wrapper">
        <form method="post" id="myaccount-form" name="myaccount_form">
            <?php
            $userId = $_SESSION['user_id'];
            $sql = "SELECT * FROM registration WHERE user_id = ?";
            $stmt = mysqli_prepare($con, $sql);
            mysqli_stmt_bind_param($stmt, "s", $userId);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if ($result && mysqli_num_rows($result) > 0) {
               while($user_data = mysqli_fetch_assoc($result)){

                ?>
                 <h1>User Account</h1>
            <div class="input-box">
                <h3>Username</h3>
                <input class="form-input" type="text" placeholder="Username" required name="username" value="<?php echo isset($user_data['username']) ? htmlspecialchars($user_data['username']) : ''; ?>">
            </div>

            <div class="input-box">
                <h3>Email</h3>
                <input class="form-input" type="email" placeholder="Email" required name="email" value="<?php echo isset($user_data['email']) ? htmlspecialchars($user_data['email']) : ''; ?>">
            </div>

                <div class="input-box">
                    <h3>Password</h3>
                    <input class="form-input" type="password" id="password" placeholder="Password" name="password">
                </div>
            
            <input type="submit" class="update-btn" value="Update" id="update-btn" name="update">

            <input type="submit" class="delete-btn" value="Delete Account" id="delete-btn" name="delete_account" onclick="return confirm('Are you sure you want to delete your account? This action cannot be undone.');">

            <?php if($user_data): ?>
            <div class="logout-link">
                <a href="logout.php">Logout</a>
            </div>
            <?php endif; ?>

                <?php
               }
               }
                
            ?>

        
        </form>
    </div>

    <div class="back-button">
        <a href="index.php" class="back-btn">← Back to Home</a>
    </div>
</body> 
</html> 