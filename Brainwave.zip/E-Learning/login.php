<?php
session_start();

include('function.php');
include('connect.php');

$error_message = "";
$show_error = false;

if ($_SERVER['REQUEST_METHOD'] == "POST") {   
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if (!empty($username) && !empty($password)) {
        if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        $query = "SELECT * FROM registration WHERE username = ?";
        $stmt = mysqli_prepare($con, $query);
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if ($result && mysqli_num_rows($result) > 0) {
            $user_data = mysqli_fetch_assoc($result);
            if ($user_data['password'] === $password) {
                $_SESSION['user_id'] = $user_data['user_id'];
                header("Location: index.php");
                exit();
            } else {
                $error_message = "Incorrect username or password";
                $show_error = true;
            }
        } else {
            $error_message = "Incorrect username or password";
            $show_error = true;
        }
    }
}
?>

<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="styles/login.css">
    <link rel="stylesheet" href="styles/navbar.css">
</head>

<body>
    <nav class="navbar">
        <div class="nav-brand">Brainwave</div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="english.html">English</a></li>
            <li><a href="mathciamtic.html">Mathciamtic</a></li>
            <li><a href="user.php">Account</a></li>
            <li><a href="support.html">Support</a></li>
        </ul>
    </nav> 
    
    <div class="wrapper">
        <form method="post" id="loginForm">
            <h1>Login</h1>

            <div class="error-message" id="errorMessage" style="display: <?php echo $show_error ? 'block' : 'none'; ?>;">
                <?php echo $error_message; ?>
            </div>

            <div class="input-box">
                <input type="text" name="username" placeholder="Username" required>
            </div>

            <div class="input-box">
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <div class="remember-forgot">
                <a href="forgetpassword.html">Forgot password</a>
            </div>

            <input type="submit" class="login-btn" value="Login">
 
            <div class="register-link">
                <p>Don't have an account? <a href="register.php">Register</a></p>
            </div>
        </form>
    </div>

    <script>
        // Show error message for a few seconds if there is an error
        <?php if ($show_error): ?>
            document.getElementById('errorMessage').style.display = 'block';
            setTimeout(function() {
                document.getElementById('errorMessage').style.display = 'none';
            }, 3000);
        <?php endif; ?>

        // Hide error message when user starts typing
        document.querySelectorAll('input').forEach(input => {
            input.addEventListener('input', function() {
                document.getElementById('errorMessage').style.display = 'none';
            });
        });

        // Prevent form resubmission on refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>
