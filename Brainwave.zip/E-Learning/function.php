<?php

    function check_login()
    {
        if(isset($_SESSION['user_id']))
        {
            $id = $_SESSION['user_id'];
            $query = "SELECT * FROM registration WHERE user_id = '$id' LIMIT 1";
            
            $result = mysqli_query($con,$query);
            if($result && mysqli_num_rows($result) > 0)
            {
                $user_data = mysqli_fetch_assoc($result);
                return $user_data;
            }
        }
        header("Location: login.php");
        die;
    }

    function random_num($length)
    {
        $text = "";
        if($length< 5)
        {
            $length = 5;
        }
        $len = rand(4,$length);
        for ($i=0; $i < $len; $i++) {
            $text .= rand(0,9);
        }
        return $text;
    }
    



    
    function updateUserDetails($userId, $username, $email, $password = null) {
        $databaseConnection = getDatabaseConnection(); 

        try {
            // Prepare the SQL statement
            $query = "UPDATE registration SET username = :username, email = :email";
            
            if ($password !== null) {
                $query .= ", password = :password";
            }
            
            $query .= " WHERE user_id = :user_id";
            
            $statement = $databaseConnection->prepare($query);
            
            // Bind parameters
            $statement->bindParam(':username', $username);
            $statement->bindParam(':email', $email);
            if ($password !== null) {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Hash the password
                $statement->bindParam(':password', $hashedPassword);
            }
            $statement->bindParam(':user_id', $userId);
            
            // Execute the statement
            if (!$statement->execute()) {
                // Log the error message
                error_log("Database update error: " . implode(", ", $statement->errorInfo()));
                return false; // Indicate failure
            }
            return true; // Indicate success
        } catch (PDOException $e) {
            // Log the error message
            error_log("Database update error: " . $e->getMessage());
            return false; // Indicate failure
        }
    }

    function getDatabaseConnection() {
        $dbhost = 'localhost';
        $dbuser = 'add';
        $dbpass = '1234';
        $dbname = 'detail';

        try {
            
            $pdo = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
        
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $pdo; 
        } catch (PDOException $e) {
            
            die("Could not connect to the database: " . $e->getMessage());
        }
    }

?>