<?php

session_start();

include('connect.php');


// Query to get the most recent booking
$query = "SELECT * FROM booking ORDER BY id DESC LIMIT 1"; 
$result = mysqli_query($con, $query);
$latestBooking = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/confirm.css">
    <link rel="stylesheet" href="styles/navbar.css">    
    <title>Confirm</title>
</head>
<body>
    <nav class="navbar">
        <div class="nav-brand">Brainwave</div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="english.html">English</a></li>
            <li><a href="mathciamtic.html">Mathciamtic</a></li>
            <li><a href="user.php">Account</a></li>
            <li><a href="support.html">Support</a></li>
        </ul>
    </nav> 

    <h1>Confirmation</h1>

    <div class="container">
        <div class="content">
            <h2>You have successfully booked a session with the tutor</h2>
            <p>Payment details</p>
            <p>Cardholder Name: <span id="name"></span></p>
            <p>Email: <span id="email"></span></p>
            <p>Card Number: <span id="cardnum"></span></p>
            <?php
            echo 'Tutor Name: ' . htmlspecialchars($latestBooking['name']) . '<br>';
            echo 'Date and Time: ' . htmlspecialchars($latestBooking['datetime']);
            ?>
        </div>
    </div>

    <div class="back-button">
        <a href="index.php" class="back-btn">Go to Home</a>
    </div>

    <script>
        const name = localStorage.getItem('u-name');
        const email = localStorage.getItem('u-email');
        const cardnum = localStorage.getItem('u-cardnum');

        
        document.getElementById('name').textContent = name;
        document.getElementById('email').textContent = email;
        document.getElementById('cardnum').textContent = cardnum;
    </script>
</body> 
</html> 