<?php

    $dbhost = 'phpmyadmin.ecs.westminster.ac.uk';
    $dbuser = 'w1909755';
    $dbpass = 'rSNkseWMYi97';
    $dbname = 'w1909755_0';

    if(!$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname))
    {
        die("failed to connect!");
    }
?>